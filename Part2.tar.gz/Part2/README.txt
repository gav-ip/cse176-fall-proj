All documentation on how to run these is in Part2 of our github! 
I wasn't sure if I was supposed to include all of the parts for part 2 (the ones we already sent you guys)
or if we were supposed to send only the report section, so I'm sending you both within the archive, sorry in advance.


Also please note that the notebook provided in this archive does have an error as they used the same set and we didn't change the variable names
The version that trained on the LeNet5 features is on the github, it's also in the notebook, but you need to remove the "
    clf.fit(
        X_train_fold, y_train_fold,
        eval_set=[(X_val_fold, y_val_fold), 
                  (X_test, y_test)],
        verbose=False
     )"
as this changes the sample distribution a little, then you need to run it again.

The .pkl files hold the XGBoosted models for the pixel/LeNet5 features.