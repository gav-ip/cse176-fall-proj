All documentation on how to run these is in Part2 of our github! 
==========================================================================================================
To run the pickle do this (but obviously put in the correct .mat file and .pkl that you want to use
model_l = pickle.load(open("xgb_lenet_clean.pkl", "rb"))

mnist_l = scipy.io.loadmat("MNIST-LeNet5.mat")
Xtest_l = mnist_l["test_fea"]
ytest_l = mnist_l["test_gnd"].ravel()

y_pred_l = model_l.predict(Xtest_l)

test_error_l = 1 - accuracy_score(ytest_l, y_pred_l)
print("LeNet-5 feature model test error:", test_error_l)
==========================================================================================================

I wasn't sure if I was supposed to include all of the parts for part 2 (the ones we already sent you guys)
or if we were supposed to send only the report section, so I'm sending you both within the archive, sorry in advance.

Also please note that the notebook provided in this archive does have an error as they used the same set and we didn't change the variable names
The version that trained on the LeNet5 features is on the github, it's also in the notebook, but you need to remove the "
    clf.fit(
        X_train_fold, y_train_fold,
        eval_set=[(X_val_fold, y_val_fold), 
                  (X_test, y_test)],
        verbose=False
     )"
as this changes the sample distribution a little, then you need to run it again. The github holds the latest version, which might hold one model or the other
I wouldn't know which it is as it changes depending on what we need when we're making the reports, slides, and just changes to the model.

If you want to look at our findings, you can also just look at our reports and slides.

The .pkl files hold the XGBoosted models for the pixel/LeNet5 features.