## Instructions for running the code
The code for part 3 is written in 2 Jupyter notebooks so you can run it on Google Colab or whichever environment you like. Make sure to download these csvs
    - creditcard.csv
    - train.csv
    - test.csv

Also make sure to download requirements.txt as they are used to install dependencies.

In the taxi.ipynb change the paths to load the train.csv and test.csv. In the creditcardfrauddetection.ipynb you should also change the file path to where creditcard.csv is saved. In both files, the %pip install -r ../requirements.txt should be changed to where you saved the text file.

Get the taxi dataset: https://www.kaggle.com/competitions/nyc-taxi-trip-duration/overview
Credit card fraud: https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud
